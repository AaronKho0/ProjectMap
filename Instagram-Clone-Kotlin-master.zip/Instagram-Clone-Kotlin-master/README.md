# Instagram-Clone-Kotlin
Youtube videos source code for Instagram clone written in Kotlin. Watch Full Course >>> [Instagram Clone Course](https://www.youtube.com/playlist?list=PLyVnb2byWwpl4ykCp1aDIH0gjVzMIxAtV)

![github-preview](https://user-images.githubusercontent.com/1303861/38796313-bbc234e6-4163-11e8-99b4-1d81ac4f64ef.png)

# How to use this app
1. Register to [firebase](https://firebase.google.com/) and create firebase application
2. Add android application with the package name `com.alexbezhan.instagram`
3. Download `google-services.json` and add it to inside `app` folder
4. Run the app
