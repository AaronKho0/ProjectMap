package com.alexbezhan.instagram.screens.home

data class FeedPostLikes(val likesCount: Int, val likedByUser: Boolean)